#pragma once

void startWiFi();